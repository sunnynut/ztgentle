#!/usr/bin/env python
#-*- coding:utf-8 -*-
import sys
sys.path.append('/home/pcsmaster/dwetl/LIB/py')
from wwpy.dajie.etl.LogETL import run


if __name__ == '__main__':
    run()
    
